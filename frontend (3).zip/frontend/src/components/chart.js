import React, { useState } from "react";
import axios from "axios";  // ✅ Import axios
import AudioRecorder from "./AudioRecorder";

function Chat() {
  const [messages, setMessages] = useState([]);  // ✅ Define state

  const handleAudioUpload = async (audioFile) => {
    const formData = new FormData();
    formData.append("audio_file", audioFile);

    try {
      const response = await axios.post("http://127.0.0.1:8000/voice-input/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      const { text_response, audio_file } = response.data;

      setMessages([...messages, 
        { user: "You", text: "Sent voice message" }, 
        { user: "Bot", text: text_response }
      ]);

      const audio = new Audio(audio_file);
      audio.play();
    } catch (error) {
      console.error("Error sending audio:", error);
    }
  };

  return (
    <div>
      <div>
        {messages.map((msg, index) => (
          <p key={index}><b>{msg.user}:</b> {msg.text}</p>
        ))}
      </div>
      <AudioRecorder onAudioUpload={handleAudioUpload} />
    </div>
  );
}

export default Chat;
