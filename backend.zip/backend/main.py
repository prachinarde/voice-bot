from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from stt import speech_to_text
from nlu import process_intent
from response import generate_response
from tts import text_to_speech
from database import fetch_faq
import os
from fastapi.staticfiles import StaticFiles

app = FastAPI()

# ✅ Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/voice-input/")
async def handle_voice(audio_file: UploadFile = File(...)):
    transcript = speech_to_text(audio_file.file)
    intent, entities = process_intent(transcript)
    
    if intent == "faq":
        response = fetch_faq(transcript)
    else:
        response = generate_response(transcript)

    audio_response = text_to_speech(response)
    
    return {"text_response": response, "audio_file": audio_response}

frontend_path = os.path.abspath("../frontend/build/static")
if not os.path.exists(frontend_path):
    raise RuntimeError(f"Directory '{frontend_path}' does not exist")

app.mount("/static", StaticFiles(directory=frontend_path), name="static")

