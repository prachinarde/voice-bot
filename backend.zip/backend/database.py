from pymongo import MongoClient
import os
from dotenv import load_dotenv
load_dotenv()
client = MongoClient(os.getenv("MONGO_URI"))
db = client["voice_bot"]
faq_collection = db["faqs"]

def fetch_faq(question):
    faq = faq_collection.find_one({"question": question})
    return faq["answer"] if faq else "I don't have an answer for that."
