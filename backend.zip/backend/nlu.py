from transformers import pipeline

classifier = pipeline("text-classification", model="facebook/bart-large-mnli")

def process_intent(text):
    labels = ["faq", "greeting", "account_query"]
    result = classifier(text)
    intent = result[0]['label']
    return intent, None  # Future: Extract entities (e.g., account number)
