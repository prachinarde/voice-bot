from pymongo import MongoClient
from pydantic import BaseModel

# Database Connection
client = MongoClient("mongodb://localhost:27017/")
db = client["voice_bot"]

# Define User Model
class User(BaseModel):
    name: str
    phoneNumber: str
    email: str
    accountDetails: dict

# Define FAQ Model
class FAQ(BaseModel):
    question: str
    answer: str
