import openai
import io
import os
from dotenv import load_dotenv

# Load API key from .env file (if used)
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")  # ✅ Set API Key explicitly

def speech_to_text(audio_file):
    try:
        audio_bytes = audio_file.read()
        transcript = openai.audio.transcriptions.create(
            model="whisper-1",
            file=io.BytesIO(audio_bytes),
            response_format="text"  # Ensures the response is plain text
        )
        return transcript
    except Exception as e:
        print("Speech-to-Text Error:", str(e))
        return "Error processing audio"
